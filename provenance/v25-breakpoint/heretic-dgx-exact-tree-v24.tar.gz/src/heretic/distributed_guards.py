# SPDX-License-Identifier: AGPL-3.0-or-later


def require_local_model_operation(*, distributed: bool, operation: str) -> None:
    if distributed:
        raise RuntimeError(
            f"{operation} is not available for DGX distributed models until "
            "the operation is implemented collectively"
        )
