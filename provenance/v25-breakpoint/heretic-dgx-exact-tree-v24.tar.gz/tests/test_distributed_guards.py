# SPDX-License-Identifier: AGPL-3.0-or-later

import pytest

from heretic.distributed_guards import require_local_model_operation


@pytest.mark.parametrize(
    "operation",
    ["merged export", "upload", "streaming chat", "benchmark"],
)
def test_rejects_rank_local_operation_for_distributed_model(operation: str) -> None:
    with pytest.raises(RuntimeError, match=f"{operation}.*not available"):
        require_local_model_operation(distributed=True, operation=operation)


def test_allows_existing_local_model_operations() -> None:
    require_local_model_operation(distributed=False, operation="benchmark")
